def add(n,n1):
    return round(n+n1)
def minus(n,n1):
    return round(n-n1)
def multiply(n,n1):
    return round(n*n1)
def divide (n,n1):
    return round(n/n1,ndigits=3)
def elevate(n,n1):
    return round(pow(n,n1))


print('1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.Elevate')
operation=input('Which operation would you like?')
while operation not in ('1','2','3','4','5'):
    operation=input('Please choose the corresponding number to the equation!')
n = int(input('Number 1: '))
n1 = int(input('Number 2: '))
if operation=='1':
    print('The answer is', add(n,n1))
elif operation=='2':
    print('The answer is', minus(n,n1))
elif operation=='3':
    print('The answer is', multiply(n,n1))
elif operation=='4':
    print('The answer is', divide(n,n1))
elif operation=='5':
    print('The answer is', elevate(n,n1))